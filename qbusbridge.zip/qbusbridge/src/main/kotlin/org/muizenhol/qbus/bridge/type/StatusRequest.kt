package org.muizenhol.qbus.bridge.type

enum class StatusRequest {
    SEND_ALL_STATES
}