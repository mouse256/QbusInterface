package org.muizenhol.qbus.bridge.type

enum class MqttHandled {
    OK,
    MQTT_ERROR,
    DATA_ERROR,
    DATA_TYPE_NOT_SUPPORTED
}