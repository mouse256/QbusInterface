package org.muizenhol.qbus.bridge

enum class Environment {
    PROD,
    DEV
}